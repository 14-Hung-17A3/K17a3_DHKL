num1 = float(input("Nhập số thứ nhất: "))
num2 = float(input("Nhập số thứ hai: "))
num3 = float(input("Nhập số thứ ba: "))

max_num = max(num1, num2, num3)

print("Số lớn nhất trong ba số bạn nhập là: ", max_num)