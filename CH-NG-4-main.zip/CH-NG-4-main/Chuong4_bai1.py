number = float(input("Nhập một số: "))

if number > 0:
    square = number ** 2
    print("Bình phương của", number, "là", square)
else:
    print("Số không hợp lệ. Vui lòng nhập một số dương.")
    