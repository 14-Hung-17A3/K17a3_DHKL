N = int(input("Nhập một số tự nhiên: "))

print("Các số nguyên từ 1 đến",N, "là:")
for i in range(1, N + 1):
    print(i, end=" ")   