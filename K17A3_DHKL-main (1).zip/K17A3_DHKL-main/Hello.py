#Đây là chương trình đầu tiên
print("Hello lớp K17A3 KHDL, 2023")
