#Chương trình thứ hai
#Tính toán số học nào
x=10
y=5
tong=x+y
hieu=5
tich=x*y
thuong=x/y
print('Tổng của hai số là',x, '+', y, '=', tong)
print('Hiệu của hai số là',x, '-', y, '=', hieu)
print('Tích của hai số là',x, '*',y, '=', tich)
print('Thương của hai số là', x,'/',y, '=', thuong)
