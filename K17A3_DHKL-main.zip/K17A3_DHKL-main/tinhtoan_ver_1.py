#Chương trình thứ hai
#Tính toán số học nào
x=10
y=5
tong=x+y
hieu=5
tich=x*y
thuong=x/y
print('Tổng của hai số    ', x, '+', y, '=',tong)
print('Hiệu của hai số    ', x, '-', y, '=',hieu)
print('Tích của hai số    ', x, '*', y, '=',tich)
print('Thuong của hai số  ', x, '/', y, '=',thuong)

